# DEZ Cyber Security Awareness Bot

 Student Information
-Name: Tshepo Lebenya
- Student Number: ST10490745
- Module: Programming(PROG6221)
- Assignment: Part 2 � Cybersecurity Awareness Chatbot



# Project Description

DEZ Cyber Security Awareness Bot is a Windows Forms chatbot application developed in C#. The chatbot helps users learn about cybersecurity topics such as:

- Password Safety
- Phishing
- Privacy
- Online Scams

The chatbot uses keyword recognition, random responses, memory recall, sentiment detection, and a graphical user interface to create an interactive user experience.



# Features

## GUI Interface
- Windows Forms GUI
- RichTextBox chat display
- User input textbox
- Send and Exit buttons
- Hacker-style colour theme

## Cybersecurity Assistance
The chatbot provides advice on:
- Password protection
- Phishing scams
- Privacy settings
- Safe browsing

## Random Responses
The bot randomly selects responses from predefined lists to make conversations more dynamic.

## Memory and Recall
The chatbot remembers the user's name during the conversation.

Example:
User: My name is John  
Bot: Nice to meet you John!

## Sentiment Detection
The chatbot detects simple emotions such as:
- worried
- confused
- frustrated

and responds supportively.

## Error Handling
The chatbot handles unknown inputs gracefully without crashing.

## Voice Greeting
A WAV greeting sound plays when the application starts.



# Technologies Used

- C#
- Windows Forms
- .NET
- Visual Studio 2022

---

# How to Run the Program

1. Open the solution in Visual Studio.
2. Build the solution.
3. Run the application.
4. Type a cybersecurity question into the textbox.
5. Click Send.

---

# Files Included

- Form1.cs
- Form1.Designer.cs
- Program.cs
- greeting.wav
- README.md

---

# GitHub Requirements

This project includes:
- Multiple commits
- Release tags
- Full source code
- Multimedia resources

---

# Author

Developed by: YOUR NAME