﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Media;
using System.Windows.Forms;

namespace DezCyberSecurityBotGui 
{
    public partial class Form1 : Form
    {
        // =====================================================
        // MEMORY VARIABLES
        // =====================================================

        string userName = "";
        string favouriteTopic = "";

        // =====================================================
        // RANDOM OBJECT
        // =====================================================

        Random random = new Random();

        // =====================================================
        // SENTIMENT WORDS
        // =====================================================

        List<string> worriedWords = new List<string>()
        {
            "worried",
            "afraid",
            "scared",
            "confused",
            "frustrated"
        };

        // =====================================================
        // KEYWORD RESPONSES
        // =====================================================

        Dictionary<string, List<string>> keywordResponses =
            new Dictionary<string, List<string>>()
        {
            {
                "password",
                new List<string>()
                {
                    "Use strong passwords with uppercase, lowercase, numbers and symbols.",
                    "Never share your password with anyone.",
                    "Enable two-factor authentication for extra security."
                }
            },

            {
                "phishing",
                new List<string>()
                {
                    "Phishing is when hackers trick you into giving personal information.",
                    "Always verify emails and avoid suspicious links.",
                    "Be careful of fake websites and suspicious attachments."
                }
            },

            {
                "safe browsing",
                new List<string>()
                {
                    "Always check URLs before clicking links.",
                    "Avoid downloading files from unknown websites.",
                    "Keep your browser and software updated."
                }
            },

            {
                "virus",
                new List<string>()
                {
                    "Install trusted antivirus software.",
                    "Avoid downloading unknown files.",
                    "Scan USB devices before opening them."
                }
            },

            {
                "privacy",
                new List<string>()
                {
                    "Review your social media privacy settings regularly.",
                    "Do not share sensitive information publicly online.",
                    "Use secure websites that begin with HTTPS."
                }
            },

            {
                "scam",
                new List<string>()
                {
                    "Scammers often pretend to be trusted companies.",
                    "Never share banking details online.",
                    "Always verify suspicious messages before responding."
                }
            }
        };

        // =====================================================
        // CONSTRUCTOR
        // =====================================================

        public Form1()
        {
            InitializeComponent();

            DisplayLogo();

            PlayVoiceGreeting();
        }

        // =====================================================
        // DISPLAY ASCII LOGO
        // =====================================================

        private void DisplayLogo()
        {
            rtbChat.SelectionColor = Color.Lime;

            rtbChat.AppendText("=====================================================\n");
            rtbChat.AppendText("                 DEZ CYBER SECURITY BOT\n");
            rtbChat.AppendText("=====================================================\n");

            rtbChat.AppendText(@"

     ██████╗ ███████╗███████╗
     ██╔══██╗██╔════╝╚══███╔╝
     ██║  ██║█████╗    ███╔╝
     ██║  ██║██╔══╝   ███╔╝
     ██████╔╝███████╗███████╗
     ╚═════╝ ╚══════╝╚══════╝

        CYBERSECURITY AWARENESS BOT
           Stay Safe Online

");

            rtbChat.AppendText("=====================================================\n\n");

            rtbChat.AppendText("DEZ: Welcome to the Cybersecurity Awareness Bot!\n");
            rtbChat.AppendText("DEZ: I am here to help you stay safe online.\n");
            rtbChat.AppendText("DEZ: Ask me about passwords, phishing, scams, viruses or privacy.\n\n");
        }

        // =====================================================
        // PLAY GREETING SOUND
        // =====================================================

        private void PlayVoiceGreeting()
        {
            try
            {
                var player = new SoundPlayer("greeting.wav");
                player.Play();
            }
            catch
            {
                rtbChat.AppendText("DEZ: Greeting audio file not found.\n");
            }
        }

        // =====================================================
        // SEND BUTTON
        // =====================================================

        private void btnSend_Click(object sender, EventArgs e)
        {
            string input = txtUserInput.Text.ToLower().Trim();

            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Please enter a message.");
                return;
            }

            rtbChat.AppendText("\nYou: " + input + "\n");

            ProcessInput(input);

            txtUserInput.Clear();
        }

        // =====================================================
        // MAIN CHATBOT LOGIC
        // =====================================================

        private void ProcessInput(string input)
        {
            // =====================================================
            // MEMORY FEATURE
            // =====================================================

            if (input.Contains("my name is"))
            {
                userName = input.Replace("my name is", "").Trim();

                rtbChat.AppendText("DEZ: Nice to meet you " + userName + "!\n");

                return;
            }

            if (input.Contains("i like"))
            {
                favouriteTopic = input.Replace("i like", "").Trim();

                rtbChat.AppendText("DEZ: Great! I will remember that you like " + favouriteTopic + ".\n");

                return;
            }

            if (input.Contains("what do you remember"))
            {
                rtbChat.AppendText("DEZ: ");

                if (userName != "")
                {
                    rtbChat.AppendText("Your name is " + userName + ". ");
                }

                if (favouriteTopic != "")
                {
                    rtbChat.AppendText("You are interested in " + favouriteTopic + ". ");
                }

                rtbChat.AppendText("\n");

                return;
            }

            // =====================================================
            // PART 1 FEATURES
            // =====================================================

            if (input.Contains("how are you"))
            {
                rtbChat.AppendText("DEZ: I'm doing great! I'm here to help keep you safe online.\n");
                return;
            }

            if (input.Contains("purpose"))
            {
                rtbChat.AppendText("DEZ: My purpose is to educate users about cybersecurity and online safety.\n");
                return;
            }

            if (input.Contains("what can i ask"))
            {
                rtbChat.AppendText("DEZ: You can ask about passwords, phishing, safe browsing, scams or viruses.\n");
                return;
            }

            if (input.Contains("help"))
            {
                rtbChat.AppendText("DEZ: I can help with:\n");
                rtbChat.AppendText(" - Password safety\n");
                rtbChat.AppendText(" - Phishing awareness\n");
                rtbChat.AppendText(" - Safe browsing\n");
                rtbChat.AppendText(" - Cybersecurity basics\n");

                return;
            }

            // =====================================================
            // SENTIMENT DETECTION
            // =====================================================

            foreach (string word in worriedWords)
            {
                if (input.Contains(word))
                {
                    rtbChat.AppendText("DEZ: I understand your concern.\n");
                    rtbChat.AppendText("DEZ: Cyber threats can be stressful, but staying informed helps protect you online.\n");
                    rtbChat.AppendText("DEZ: Remember not to click suspicious links or share personal information.\n");

                    return;
                }
            }

            // =====================================================
            // CONVERSATION FLOW
            // =====================================================

            if (input.Contains("tell me more"))
            {
                rtbChat.AppendText("DEZ: Cybersecurity protects systems, networks and personal information from attacks.\n");

                return;
            }

            if (input.Contains("another tip"))
            {
                rtbChat.AppendText("DEZ: Always keep your software and antivirus updated.\n");

                return;
            }

            // =====================================================
            // RANDOM KEYWORD RESPONSES
            // =====================================================

            bool found = false;

            foreach (var keyword in keywordResponses.Keys)
            {
                if (input.Contains(keyword))
                {
                    found = true;

                    List<string> responses = keywordResponses[keyword];

                    int index = random.Next(responses.Count);

                    string response = responses[index];

                    // Personalised responses
                    if (userName != "")
                    {
                        response = userName + ", " + response;
                    }

                    rtbChat.AppendText("DEZ: " + response + "\n");

                    break;
                }
            }

            // =====================================================
            // EXIT APPLICATION
            // =====================================================

            if (input.Contains("exit"))
            {
                rtbChat.AppendText("DEZ: Goodbye! Stay safe online!\n");

                Application.Exit();
            }

            // =====================================================
            // ERROR HANDLING
            // =====================================================

            if (!found &&
                !input.Contains("how are you") &&
                !input.Contains("purpose") &&
                !input.Contains("what can i ask") &&
                !input.Contains("help") &&
                !input.Contains("tell me more") &&
                !input.Contains("another tip"))
            {
                rtbChat.AppendText("DEZ: I didn't quite understand that. Could you rephrase?\n");
            }
        }

        // =====================================================
        // EXIT BUTTON
        // =====================================================

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}